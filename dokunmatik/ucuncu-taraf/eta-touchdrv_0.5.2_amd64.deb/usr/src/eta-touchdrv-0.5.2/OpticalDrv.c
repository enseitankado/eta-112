#include <linux/cdev.h>
#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/hid.h>
#include <linux/init.h>
#include <linux/input.h>
#include <linux/input/mt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/uaccess.h>
#include <linux/usb.h>
#include <linux/usb/input.h>
#include <linux/version.h>

#include <OpticalDrv.h>

#define DRIVER_NAME "Optical touch device"

#define err(format, arg...) pr_err(KBUILD_MODNAME ": " format "\n", ##arg)
#define info(format, arg...) pr_info(KBUILD_MODNAME ": " format "\n", ##arg)

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 8, 0))
#define strlcpy strscpy
#endif

#define OPTICAL_MINOR_BASE 0

static unsigned int touch_antishake_radius = 24;
module_param_named(touch_antishake_radius, touch_antishake_radius, uint, 0644);
MODULE_PARM_DESC(touch_antishake_radius,
                 "Deadband radius for touch jitter suppression");

static unsigned int touch_smoothing_weight = 1;
module_param_named(touch_smoothing_weight, touch_smoothing_weight, uint, 0644);
MODULE_PARM_DESC(touch_smoothing_weight,
                 "Low-pass filter weight for reported touch coordinates");

static const struct optical_variant variant_irtouch = {
    .dev_node_fmt = "IRTouchOptical%03d",
    .touch_points = 2,
};

static const struct optical_variant variant_raw = {
    .dev_node_fmt = "OtdUsbRaw%03d",
    .touch_points = 10,
};

static struct usb_device_id const dev_table[] = {
    {USB_DEVICE(0x6615, 0x0084),
     .driver_info = (kernel_ulong_t)&variant_irtouch},
    {USB_DEVICE(0x6615, 0x0085),
     .driver_info = (kernel_ulong_t)&variant_irtouch},
    {USB_DEVICE(0x6615, 0x0086),
     .driver_info = (kernel_ulong_t)&variant_irtouch},
    {USB_DEVICE(0x6615, 0x0087),
     .driver_info = (kernel_ulong_t)&variant_irtouch},
    {USB_DEVICE(0x6615, 0x0088),
     .driver_info = (kernel_ulong_t)&variant_irtouch},
    {USB_DEVICE(0x6615, 0x0c20),
     .driver_info = (kernel_ulong_t)&variant_irtouch},
    {USB_DEVICE(0x2621, 0x2201), .driver_info = (kernel_ulong_t)&variant_raw},
    {USB_DEVICE(0x2621, 0x4501), .driver_info = (kernel_ulong_t)&variant_raw},
    {}};

static struct file_operations optical_fops;
static struct usb_driver optical_driver;
static DEFINE_MUTEX(optical_file_lock);

static int submit_urb(device_context *device, gfp_t gfp_mask) {
  int retval;

  retval = usb_submit_urb(device->interrupt_urb, gfp_mask);
  if (retval != 0) {
    err("%s: usb_submit_urb failed: %d", __func__, retval);
  }
  return retval;
}
static void cancel_urb(device_context *device) {
  usb_kill_urb(device->interrupt_urb);
}

static bool optical_has_active_consumer(device_context *device) {
  return device->file_private_data != NULL || device->input_device_open;
}

static int optical_ensure_urb_started(device_context *device, gfp_t gfp_mask) {
  int retval;

  mutex_lock(&optical_file_lock);
  if (device->disconnected) {
    mutex_unlock(&optical_file_lock);
    return -ENODEV;
  }
  if (device->urb_submitted) {
    mutex_unlock(&optical_file_lock);
    return 0;
  }
  device->urb_submitted = true;
  mutex_unlock(&optical_file_lock);

  retval = submit_urb(device, gfp_mask);
  if (retval == 0)
    return 0;

  mutex_lock(&optical_file_lock);
  device->urb_submitted = false;
  mutex_unlock(&optical_file_lock);
  return retval;
}

static void optical_maybe_stop_urb(device_context *device) {
  bool need_cancel;

  mutex_lock(&optical_file_lock);
  need_cancel = !device->disconnected && device->urb_submitted &&
                !optical_has_active_consumer(device);
  if (need_cancel)
    device->urb_submitted = false;
  mutex_unlock(&optical_file_lock);

  if (need_cancel)
    cancel_urb(device);
}

static void reset_touch_filter(device_context *device, size_t slot) {
  device->touch_filter[slot].primed = false;
  device->touch_filter[slot].x = 0;
  device->touch_filter[slot].y = 0;
}

static void apply_touch_filter(device_context *device, size_t slot,
                               signed short *x, signed short *y,
                               bool touched) {
  unsigned long long dx;
  unsigned long long dy;
  unsigned long long radius_sq;
  unsigned long long delta_sq;
  long long filtered_x;
  long long filtered_y;
  int weight;
  int prev_x;
  int prev_y;

  if (!touched) {
    reset_touch_filter(device, slot);
    return;
  }

  if (!device->touch_filter[slot].primed) {
    device->touch_filter[slot].primed = true;
    device->touch_filter[slot].x = *x;
    device->touch_filter[slot].y = *y;
    return;
  }

  prev_x = device->touch_filter[slot].x;
  prev_y = device->touch_filter[slot].y;
  dx = (unsigned long long)abs((int)*x - prev_x);
  dy = (unsigned long long)abs((int)*y - prev_y);
  radius_sq = (unsigned long long)touch_antishake_radius *
              (unsigned long long)touch_antishake_radius;
  delta_sq = dx * dx + dy * dy;
  if (touch_antishake_radius != 0 && delta_sq <= radius_sq) {
    *x = (signed short)prev_x;
    *y = (signed short)prev_y;
    return;
  }

  weight = (int)touch_smoothing_weight;
  if (weight > 0) {
    filtered_x = ((long long)prev_x * weight + (int)*x) / (weight + 1);
    filtered_y = ((long long)prev_y * weight + (int)*y) / (weight + 1);
    *x = (signed short)filtered_x;
    *y = (signed short)filtered_y;
  }

  device->touch_filter[slot].x = *x;
  device->touch_filter[slot].y = *y;
}

static ssize_t optical_read(struct file *filp, char __user *buffer,
                            size_t count, loff_t *ppos) {
  size_t avail;
  device_context *device;
  unsigned char local_buf[256];
  int r;

  device = filp->private_data;
  if (device == NULL)
    return -EFAULT;

  if (count == 0)
    return 0;

  if ((filp->f_flags & O_NONBLOCK) != 0 &&
      READ_ONCE(device->buffer_length) == 0)
    return -EAGAIN;

  r = wait_event_interruptible(device->read_wait,
                               READ_ONCE(device->buffer_length) > 0 ||
                                   READ_ONCE(device->disconnected));
  if (r != 0)
    return -EINTR;
  if (READ_ONCE(device->disconnected))
    return -ENODEV;

  spin_lock_irq(&device->lock);
  avail = device->buffer_length;
  if (avail == 0) {
    spin_unlock_irq(&device->lock);
    return 0;
  }
  if (count > avail)
    count = avail;
  if (count > sizeof(local_buf))
    count = sizeof(local_buf);
  memcpy(local_buf, device->buffer, count);
  device->buffer_length = 0;
  spin_unlock_irq(&device->lock);

  if (copy_to_user(buffer, local_buf, count) != 0)
    return -EFAULT;

  return (ssize_t)count;
}

static ssize_t optical_write(struct file *filp, const char *user_buffer,
                             size_t count, loff_t *ppos) {
  device_context *device;

  device = filp->private_data;
  if (device == NULL) {
    return -EFAULT;
  }

  return -EFAULT;
}

static long set_report(device_context *device, unsigned short length,
                       void const *data) {
  void *kernel_data;
  int r;

  kernel_data = kzalloc(length, GFP_KERNEL);
  if (kernel_data == NULL) {
    return -ENOMEM;
  }
  do {
    r = copy_from_user(kernel_data, data, length);
    if (r != 0) {
      r = -EFAULT;
      break;
    }
    if (length < 1) {
      r = -EINVAL;
      break;
    }
    r = usb_control_msg(device->usb_device,
                        usb_sndctrlpipe(device->usb_device, 0), 0, 0x40, 0, 0,
                        kernel_data, length, 1000);
    kfree(kernel_data);
    return r;
  } while (false);
  kfree(kernel_data);
  return r;
}
static long get_report(device_context *device, unsigned short length,
                       void *data) {
  void *kernel_data;
  int r;

  kernel_data = kzalloc(length, GFP_KERNEL);
  if (kernel_data == NULL) {
    return -ENOMEM;
  }
  do {
    if (length < 1) {
      r = -EINVAL;
      break;
    }
    r = usb_control_msg(device->usb_device,
                        usb_rcvctrlpipe(device->usb_device, 0), 0, 0xc0, 0, 0,
                        kernel_data, length, 1000);
    if (r >= 0) {
      if (copy_to_user(data, kernel_data, r) != 0) {
        r = -EFAULT;
        break;
      }
    }
    kfree(kernel_data);
    return r;
  } while (false);
  kfree(kernel_data);
  return r;
}
static long sync_absolute_mouse(device_context *device, unsigned short length,
                                void const *data) {
  // TODO
  return 0;
}

static long sync_touch_points(device_context *device,
                              const OpticalReportTouchPoint *touch_points,
                              size_t touch_point_count) {
  size_t i;

  for (i = 0; i < touch_point_count; i++) {
    bool touched;

    if ((touch_points[i].state & OpticalReportTouchPointStateFlag_IsValid) ==
        0) {
      // Daemons can send partial updates; invalid slots mean no change.
      continue;
    }

    input_mt_slot(device->input_dev, i);

    touched = (touch_points[i].state & OpticalReportTouchPointStateFlag_IsTouched) !=
              0;
    input_mt_report_slot_state(device->input_dev, MT_TOOL_FINGER, touched);

    if (touched) {
      signed short x = touch_points[i].x;
      signed short y = touch_points[i].y;

      apply_touch_filter(device, i, &x, &y, true);
      device->active_touch_slots |= BIT(i);
      input_report_abs(device->input_dev, ABS_MT_TOUCH_MAJOR,
                       touch_points[i].width);
      input_report_abs(device->input_dev, ABS_MT_TOUCH_MINOR,
                       touch_points[i].height);
      input_report_abs(device->input_dev, ABS_MT_POSITION_X, x);
      input_report_abs(device->input_dev, ABS_MT_POSITION_Y, y);
    } else {
      device->active_touch_slots &= ~BIT(i);
      reset_touch_filter(device, i);
    }
  }

  input_report_key(device->input_dev, BTN_TOUCH,
                   device->active_touch_slots != 0);
  input_sync(device->input_dev);
  return 0;
}

static void release_touch_points(device_context *device) {
  size_t i;

  if (device->input_dev == NULL)
    return;

  for (i = 0; i < device->variant->touch_points; i++) {
    input_mt_slot(device->input_dev, i);
    input_mt_report_slot_state(device->input_dev, MT_TOOL_FINGER, false);
    reset_touch_filter(device, i);
  }

  device->active_touch_slots = 0;
  input_report_key(device->input_dev, BTN_TOUCH, 0);
  input_sync(device->input_dev);
}

static long sync_singletouch(device_context *device, unsigned short length,
                             void const *data) {
  OpticalReportPacketSingleTouch value;
  int r;

  if (length < sizeof(value)) {
    return -EINVAL;
  }

  r = copy_from_user(&value, data, sizeof(value));
  if (r != 0) {
    return -EFAULT;
  }
  sync_touch_points(device, &value.touchPoint, 1);
  return (long)sizeof(value);
}

static long sync_multitouch(device_context *device, unsigned short length,
                            void const *data) {
  OpticalReportTouchPoint *points;
  size_t touch_points;
  size_t packet_size;
  int r;

  touch_points = device->variant->touch_points;
  packet_size = OPTICAL_MULTITOUCH_PACKET_SIZE(touch_points);

  if (length < packet_size) {
    return -EINVAL;
  }

  points = kzalloc(packet_size, GFP_KERNEL);
  if (points == NULL) {
    return -ENOMEM;
  }
  r = copy_from_user(points, data, packet_size);
  if (r != 0) {
    kfree(points);
    return -EFAULT;
  }
  sync_touch_points(device, points, touch_points);
  kfree(points);
  return (long)packet_size;
}

static long sync_keyboard(device_context *device, unsigned short length,
                          void const *data) {
  // TODO
  return 0;
}
static long sync_diagnosis(device_context *device, unsigned short length,
                           void const *data) {
  // TODO
  return 0;
}
static long sync_rawtouch(device_context *device, unsigned short length,
                          void const *data) {
  // TODO
  return 0;
}
static long sync_touch(device_context *device, unsigned short length,
                       void const *data) {
  // TODO
  return 0;
}
static long sync_virtualkey(device_context *device, unsigned short length,
                            void const *data) {
  // TODO
  return 0;
}
static long optical_unlocked_ioctl(struct file *filp, unsigned int ctl_code,
                                   unsigned long ctl_param) {
  device_context *device;

  device = filp->private_data;
  if (device == NULL) {
    return -EFAULT;
  }

  switch (ctl_code & OPTICAL_IOCTL_CODE_TYPE_MASK) {
  case OPTICAL_IOCTL_CODE_TYPE_SET_REPORT:
    return set_report(device, ctl_code & OPTICAL_IOCTL_CODE_LENGTH_MASK,
                      (void const *)ctl_param);
  case OPTICAL_IOCTL_CODE_TYPE_GET_REPORT:
    return get_report(device, ctl_code & OPTICAL_IOCTL_CODE_LENGTH_MASK,
                      (void *)ctl_param);
  case OPTICAL_IOCTL_CODE_TYPE_SYNC_ABSOLUTEMOUSE:
    return sync_absolute_mouse(device,
                               ctl_code & OPTICAL_IOCTL_CODE_LENGTH_MASK,
                               (void const *)ctl_param);
  case OPTICAL_IOCTL_CODE_TYPE_SYNC_SINGLETOUCH:
    return sync_singletouch(device, ctl_code & OPTICAL_IOCTL_CODE_LENGTH_MASK,
                            (void const *)ctl_param);
  case OPTICAL_IOCTL_CODE_TYPE_SYNC_MULTITOUCH:
    return sync_multitouch(device, ctl_code & OPTICAL_IOCTL_CODE_LENGTH_MASK,
                           (void const *)ctl_param);
  case OPTICAL_IOCTL_CODE_TYPE_SYNC_KEYBOARD:
    return sync_keyboard(device, ctl_code & OPTICAL_IOCTL_CODE_LENGTH_MASK,
                         (void const *)ctl_param);
  case OPTICAL_IOCTL_CODE_TYPE_SYNC_DIAGNOSIS:
    return sync_diagnosis(device, ctl_code & OPTICAL_IOCTL_CODE_LENGTH_MASK,
                          (void const *)ctl_param);
  case OPTICAL_IOCTL_CODE_TYPE_SYNC_RAWTOUCH:
    return sync_rawtouch(device, ctl_code & OPTICAL_IOCTL_CODE_LENGTH_MASK,
                         (void const *)ctl_param);
  case OPTICAL_IOCTL_CODE_TYPE_SYNC_TOUCH:
    return sync_touch(device, ctl_code & OPTICAL_IOCTL_CODE_LENGTH_MASK,
                      (void const *)ctl_param);
  case OPTICAL_IOCTL_CODE_TYPE_SYNC_VIRTUALKEY:
    return sync_virtualkey(device, ctl_code & OPTICAL_IOCTL_CODE_LENGTH_MASK,
                           (void const *)ctl_param);
  }
  return 0;
}

static int optical_open(struct inode *inode, struct file *filp) {
  device_context *device;
  struct usb_interface *interface;
  int retval;
  int subminor;

  subminor = iminor(inode);

  interface = usb_find_interface(&optical_driver, subminor);

  if (interface == NULL) {
    err("%s: interface ptr is NULL.", __func__);
    return -ENODEV;
  }
  mutex_lock(&optical_file_lock);
  device = usb_get_intfdata(interface);
  if (device == NULL) {
    mutex_unlock(&optical_file_lock);
    err("%s: device context is NULL.", __func__);
    return -ENODEV;
  }
  if (device->disconnected) {
    mutex_unlock(&optical_file_lock);
    return -ENODEV;
  }
  if (device->file_private_data != NULL) {
    mutex_unlock(&optical_file_lock);
    return -EBUSY;
  }

  device->file_private_data = filp;
  filp->private_data = device;
  mutex_unlock(&optical_file_lock);

  retval = optical_ensure_urb_started(device, GFP_KERNEL);
  if (retval == 0)
    return 0;

  mutex_lock(&optical_file_lock);
  if (device->file_private_data == filp)
    device->file_private_data = NULL;
  filp->private_data = NULL;
  mutex_unlock(&optical_file_lock);
  return retval;
}

static int optical_release(struct inode *inode, struct file *filp) {
  device_context *device;

  mutex_lock(&optical_file_lock);
  device = filp->private_data;
  if (device != NULL) {
    release_touch_points(device);
    device->file_private_data = NULL;
  }
  filp->private_data = NULL;
  mutex_unlock(&optical_file_lock);

  if (device != NULL)
    optical_maybe_stop_urb(device);

  return 0;
}

static struct file_operations optical_fops = {
    .owner = THIS_MODULE,
    .read = optical_read,
    .write = optical_write,
    .unlocked_ioctl = optical_unlocked_ioctl,
    .open = optical_open,
    .release = optical_release,
};

static void on_interrupt(struct urb *interrupt_urb) {
  device_context *device;
  unsigned int length;

  device = interrupt_urb->context;

  switch (interrupt_urb->status) {
  case -ECONNRESET:
  case -ENOENT:
  case -ESHUTDOWN:
    return;
  }

  spin_lock(&device->lock);
  if (interrupt_urb->status == 0) {
    if (interrupt_urb->actual_length > 0) {
      length = min_t(unsigned int, interrupt_urb->actual_length,
                     device->max_packet_size);
      memcpy(device->buffer, device->ongoing_buffer, length);
      device->buffer_length = length;
    }
  }
  spin_unlock(&device->lock);

  if (interrupt_urb->status == 0 && interrupt_urb->actual_length > 0)
    wake_up_interruptible(&device->read_wait);

  mutex_lock(&optical_file_lock);
  if (device->disconnected || !device->urb_submitted ||
      !optical_has_active_consumer(device)) {
    device->urb_submitted = false;
    mutex_unlock(&optical_file_lock);
    return;
  }
  mutex_unlock(&optical_file_lock);

  if (submit_urb(device, GFP_ATOMIC) != 0) {
    mutex_lock(&optical_file_lock);
    device->urb_submitted = false;
    mutex_unlock(&optical_file_lock);
  }
}

static int optical_open_device(struct input_dev *input_dev) {
  device_context *device;

  device = input_get_drvdata(input_dev);

  mutex_lock(&optical_file_lock);
  device->input_device_open = true;
  mutex_unlock(&optical_file_lock);

  return optical_ensure_urb_started(device, GFP_KERNEL);
}

static void optical_close_device(struct input_dev *input_dev) {
  device_context *device;

  device = input_get_drvdata(input_dev);

  mutex_lock(&optical_file_lock);
  device->input_device_open = false;
  mutex_unlock(&optical_file_lock);

  optical_maybe_stop_urb(device);
}

static int device_context_init(device_context *obj,
                               struct usb_interface *intf) {
  int i;

  obj->usb_device = interface_to_usbdev(intf);

  for (i = 0; i < intf->cur_altsetting->desc.bNumEndpoints; i++) {
    if (intf->cur_altsetting->endpoint[i].desc.bEndpointAddress & USB_DIR_IN) {
      obj->pipe_input = usb_rcvintpipe(
          obj->usb_device,
          intf->cur_altsetting->endpoint[i].desc.bEndpointAddress);
      obj->max_packet_size =
          usb_endpoint_maxp(&intf->cur_altsetting->endpoint[i].desc);
      obj->pipe_interval = intf->cur_altsetting->endpoint[i].desc.bInterval;
      return 0;
    }
  }

  err("%s: no IN endpoint found", __func__);
  return -ENODEV;
}

static void input_dev_init(struct input_dev *obj, device_context *device,
                           device_context_pool *pool,
                           struct usb_device *usb_device,
                           struct device *parent) {
  if (usb_device->manufacturer != NULL) {
    strlcpy(pool->name, usb_device->manufacturer, sizeof(pool->name));
  } else {
    pool->name[0] = 0;
  }

  if (usb_device->product != NULL) {
    strlcat(pool->name, " ", sizeof(pool->name));
    strlcat(pool->name, usb_device->product, sizeof(pool->name));
  }

  if (strlen(pool->name) == 0) {
    snprintf(pool->name, sizeof(pool->name), "Optical touch device %04x:%04x",
             le16_to_cpu(usb_device->descriptor.idVendor),
             le16_to_cpu(usb_device->descriptor.idProduct));
  }

  snprintf(pool->class_name, sizeof(pool->class_name), "%s",
           device->variant->dev_node_fmt);

  usb_make_path(usb_device, pool->phys, sizeof(pool->phys));
  strlcat(pool->phys, "/input0", sizeof(pool->phys));

  obj->name = pool->name;
  obj->phys = pool->phys;

  usb_to_input_id(usb_device, &obj->id);
  obj->dev.parent = parent;

  // seems useless
  // input_set_drvdata(obj, device);

  obj->open = optical_open_device;
  obj->close = optical_close_device;

  obj->evbit[0] = BIT(EV_KEY) | BIT(EV_ABS);
  __set_bit(INPUT_PROP_DIRECT, obj->propbit);
  set_bit(BTN_TOUCH, obj->keybit);
  set_bit(EV_SYN, obj->evbit);
  set_bit(EV_KEY, obj->evbit);
  set_bit(EV_ABS, obj->evbit);
  obj->absbit[0] = BIT(ABS_MT_PRESSURE) | BIT(ABS_MT_POSITION_X) |
                   BIT(ABS_MT_POSITION_Y) | BIT(ABS_MT_TOUCH_MAJOR) |
                   BIT(ABS_MT_TOUCH_MINOR);

  input_set_abs_params(obj, ABS_MT_PRESSURE, 0, 1, 0, 0);
  input_set_abs_params(obj, ABS_MT_POSITION_X, 0, 32767, 0, 0);
  input_set_abs_params(obj, ABS_MT_POSITION_Y, 0, 32767, 0, 0);
  input_set_abs_params(obj, ABS_MT_TOUCH_MAJOR, 0, 32767, 0, 0);
  input_set_abs_params(obj, ABS_MT_TOUCH_MINOR, 0, 32767, 0, 0);
  input_mt_init_slots(obj, device->variant->touch_points, INPUT_MT_DIRECT);
}

static int optical_probe(struct usb_interface *intf,
                         const struct usb_device_id *id) {
  int retval;
  device_context *device;
  bool input_dev_registered = false;

  do {
    device = kzalloc(sizeof(device_context), GFP_KERNEL);
    if (device == NULL) {
      err("%s: Out of memory.", __func__);
      break;
    }

    memset(&device->class, 0, sizeof(device->class));
    device->file_private_data = NULL;
    device->disconnected = false;
    device->variant = (const struct optical_variant *)id->driver_info;
    device->class.name = device->pool.class_name;
    device->class.fops = &optical_fops;
    device->class.minor_base = OPTICAL_MINOR_BASE;

    do {
      retval = device_context_init(device, intf);
      if (retval != 0) {
        break;
      }
      device->input_dev = input_allocate_device();
      if (device->input_dev == NULL) {
        break;
      }
      do {
        spin_lock_init(&device->lock);
        init_waitqueue_head(&device->read_wait);
        device->urb_submitted = false;
        device->input_device_open = false;
        device->report_packet_size =
            (unsigned int)OPTICAL_MULTITOUCH_PACKET_SIZE(
                device->variant->touch_points);
        device->buffer_capacity = max(device->max_packet_size,
                                      device->report_packet_size);
        device->buffer = kzalloc(device->buffer_capacity, GFP_KERNEL);
        if (device->buffer == NULL) {
          break;
        }
        device->ongoing_buffer =
            usb_alloc_coherent(device->usb_device, device->max_packet_size,
                               GFP_ATOMIC, &device->ongoing_buffer_dma);
        if (device->ongoing_buffer == NULL) {
          kfree(device->buffer);
          device->buffer = NULL;
          break;
        }
        do {
          device->interrupt_urb = usb_alloc_urb(0, GFP_KERNEL);
          if (device->interrupt_urb == NULL) {
            break;
          }
          do {
            usb_fill_int_urb(device->interrupt_urb, device->usb_device,
                             device->pipe_input, device->ongoing_buffer,
                             device->max_packet_size, on_interrupt, device,
                             device->pipe_interval);
            device->interrupt_urb->transfer_dma = device->ongoing_buffer_dma;
            device->interrupt_urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
            device->buffer_length = 0;
            device->interrupt_urb->dev = device->usb_device;
            input_dev_init(device->input_dev, device, &device->pool,
                           device->usb_device, &intf->dev);
            input_set_drvdata(device->input_dev, device);
            retval = input_register_device(device->input_dev);
            if (retval != 0) {
              break;
            }
            input_dev_registered = true;
            do {
              usb_set_intfdata(intf, device);
              do {
                msleep(500);
                if (usb_register_dev(intf, &device->class) != 0) {
                  break;
                }
                return 0;

              } while (false);
              usb_set_intfdata(intf, NULL);
            } while (false);
          } while (false);
          usb_free_urb(device->interrupt_urb);
        } while (false);
        usb_free_coherent(device->usb_device, device->max_packet_size,
                          device->ongoing_buffer, device->ongoing_buffer_dma);
        kfree(device->buffer);
      } while (false);
      if (device->input_dev != NULL) {
        if (input_dev_registered) {
          input_unregister_device(device->input_dev);
        } else {
          input_free_device(device->input_dev);
        }
        device->input_dev = NULL;
      }
    } while (false);
    kfree(device);
  } while (false);
  return -ENOMEM;
}

static void optical_disconnect(struct usb_interface *intf) {
  device_context *device = usb_get_intfdata(intf);

  if (device == NULL) {
    return;
  }


  mutex_lock(&optical_file_lock);
  usb_deregister_dev(intf, &device->class);
  usb_set_intfdata(intf, NULL);
  device->disconnected = true;
  device->urb_submitted = false;
  device->input_device_open = false;
  if (device->file_private_data != NULL) {
    device->file_private_data->private_data = NULL;
  }
  device->file_private_data = NULL;
  mutex_unlock(&optical_file_lock);

  wake_up_interruptible(&device->read_wait);

  release_touch_points(device);
  input_unregister_device(device->input_dev);
  device->input_dev = NULL;
  usb_free_urb(device->interrupt_urb);
  usb_free_coherent(device->usb_device, device->max_packet_size,
                    device->ongoing_buffer, device->ongoing_buffer_dma);
  kfree(device->buffer);
  kfree(device);
}

static struct usb_driver optical_driver = {
    .name = DRIVER_NAME,
    .probe = optical_probe,
    .disconnect = optical_disconnect,
    .id_table = dev_table,
};

module_usb_driver(optical_driver);

MODULE_DESCRIPTION("USB driver for Optical touch screen");
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Optical touch screen");
MODULE_DEVICE_TABLE(usb, dev_table);

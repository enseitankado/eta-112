#ifndef _OPTICAL_DRV_H_
#define _OPTICAL_DRV_H_

#include <linux/wait.h>

struct file;

typedef unsigned char OpticalReportTouchPointStateFlag;
#define OpticalReportTouchPointStateFlag_None                                  \
  ((OpticalReportTouchPointStateFlag)0x00)
#define OpticalReportTouchPointStateFlag_IsValid                               \
  ((OpticalReportTouchPointStateFlag)0x01)
#define OpticalReportTouchPointStateFlag_IsTouched                             \
  ((OpticalReportTouchPointStateFlag)0x02)

#pragma pack(1)

typedef struct _OpticalReportTouchPoint {
  OpticalReportTouchPointStateFlag state;
  signed short x;
  signed short y;
  signed short width;
  signed short height;
} OpticalReportTouchPoint;

#define OPTICAL_MAX_TOUCH_POINTS 10

#define OPTICAL_FILTER_RING_SIZE 16

typedef struct _OpticalReportPacketSingleTouch {
  OpticalReportTouchPoint touchPoint;
  unsigned short scanTime;
} OpticalReportPacketSingleTouch;

typedef struct _OpticalReportPacketMultiTouch {
  OpticalReportTouchPoint touchPoint[1];
} OpticalReportPacketMultiTouch;

typedef struct _OpticalReportPacketMultiTouchTrailing {
  unsigned short scanTime;
} OpticalReportPacketMultiTouchTrailing;

#pragma pack()

#define OPTICAL_MULTITOUCH_PACKET_SIZE(touch_points)                           \
  (sizeof(OpticalReportTouchPoint) * (touch_points) +                         \
   sizeof(OpticalReportPacketMultiTouchTrailing))

struct optical_variant {
  const char *dev_node_fmt;
  int touch_points;
};

typedef struct _device_context_pool {
  char name[128];
  char class_name[32];
  char phys[64];
} device_context_pool;

typedef struct _device_context {
  struct usb_device *usb_device;
  struct input_dev *input_dev;
  struct device *device;
  dev_t dev;
  struct file *file_private_data;
  int pipe_input;
  unsigned char pipe_interval;

  struct usb_class_driver class;
  const struct optical_variant *variant;

  bool disconnected;

  struct urb *interrupt_urb;

  spinlock_t lock;
  wait_queue_head_t read_wait;

  unsigned char *ongoing_buffer;
  dma_addr_t ongoing_buffer_dma;

  unsigned int max_packet_size;
  unsigned int report_packet_size;
  unsigned int buffer_capacity;
  unsigned char *buffer; //OTD: 10 × 9 + 2 = 92 byte

  unsigned int buffer_length;
  bool urb_submitted;
  bool input_device_open;

  unsigned long active_touch_slots;
  struct {
    bool primed;
    signed short x;
    signed short y;
    unsigned long last_event_jiffies;
    int dx_ring[OPTICAL_FILTER_RING_SIZE];
    int dy_ring[OPTICAL_FILTER_RING_SIZE];
    unsigned int ring_idx;
    unsigned int ring_count;
    long sum_dx;
    long sum_dy;
  } touch_filter[OPTICAL_MAX_TOUCH_POINTS];

  device_context_pool pool;
} device_context;


// control code
#define OPTICAL_IOCTL_CODE_TYPE_MASK 0x00ff0000u

#define OPTICAL_IOCTL_CODE_TYPE_SET_REPORT 0x00100000u
#define OPTICAL_IOCTL_CODE_TYPE_GET_REPORT 0x00110000u

#define OPTICAL_IOCTL_CODE_TYPE_SYNC_ABSOLUTEMOUSE 0x00200000u
#define OPTICAL_IOCTL_CODE_TYPE_SYNC_SINGLETOUCH 0x00210000u
#define OPTICAL_IOCTL_CODE_TYPE_SYNC_MULTITOUCH 0x00220000u
#define OPTICAL_IOCTL_CODE_TYPE_SYNC_KEYBOARD 0x00230000u

#define OPTICAL_IOCTL_CODE_TYPE_SYNC_DIAGNOSIS 0x00300000u
#define OPTICAL_IOCTL_CODE_TYPE_SYNC_RAWTOUCH 0x00310000u
#define OPTICAL_IOCTL_CODE_TYPE_SYNC_TOUCH 0x00320000u
#define OPTICAL_IOCTL_CODE_TYPE_SYNC_VIRTUALKEY 0x00330000u

#define OPTICAL_IOCTL_CODE_LENGTH_MASK 0x0000ffffu

#define OPTICAL_IOCTL_CODE(type, length)                                       \
  (((type) & OPTICAL_IOCTL_CODE_TYPE_MASK) |                                   \
   ((length) & OPTICAL_IOCTL_CODE_LENGTH_MASK))

#endif // _OPTICAL_DRV_H_
